import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss']
})
export class LandingPageComponent implements OnInit {
  searchText: string = "";
  descriptionList  = [];
  
  constructor() { }

  ngOnInit(): void {
  }
  
  applyFilter(event) {
    this.searchText = event.target.value;
  }

}
