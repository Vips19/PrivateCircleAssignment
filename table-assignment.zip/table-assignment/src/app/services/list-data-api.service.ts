import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ListDataApiService {

  constructor(private httpClient: HttpClient) { }
  
  fetchListDetails() {
    return  this.httpClient.get("assets/data.json");
  }
}
