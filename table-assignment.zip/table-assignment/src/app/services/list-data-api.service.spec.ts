import { TestBed } from '@angular/core/testing';

import { ListDataApiService } from './list-data-api.service';

describe('ListDataApiService', () => {
  let service: ListDataApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ListDataApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
