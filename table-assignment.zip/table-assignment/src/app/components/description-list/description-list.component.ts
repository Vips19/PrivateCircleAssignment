import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-description-list',
  templateUrl: './description-list.component.html',
  styleUrls: ['./description-list.component.scss']
})
export class DescriptionListComponent implements OnInit {
  
  descriptionList = [];
  
  @Input() set list (data){
    console.log("child",data);
    this.descriptionList = data;
  }

  constructor() { }

  ngOnInit(): void {
  }

}
