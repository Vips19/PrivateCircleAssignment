import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ListDataApiService } from 'src/app/services/list-data-api.service';

@Component({
  selector: 'app-list-table',
  templateUrl: './list-table.component.html',
  styleUrls: ['./list-table.component.scss']
})
export class ListTableComponent implements OnInit {
  displayedColumns: string[] = ['date', 'listName', 'noOfEntities', 'actions','details'];
  listData = new MatTableDataSource([]);
  
  @Input() set filter (f: string){
    this.listData.filter = f.trim().toLowerCase();
  };
  @Output() detailsData: EventEmitter<any> = new EventEmitter();
  constructor(private fetchService: ListDataApiService) { }

  ngOnInit(): void {
    this.fetchService.fetchListDetails().subscribe( response => {
      this.listData.data = JSON.parse(JSON.stringify(response));
    });
  }
  
  showDetails(index) {
    this.detailsData.emit(this.listData.filteredData[index].description);
  }

}
